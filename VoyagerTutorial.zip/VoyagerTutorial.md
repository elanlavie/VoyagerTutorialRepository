# Second Voyager Tutorial

## Introduction

The goal of this tutorial is to take you through the whole "SETI Pipeline". That is, to take
real data gathered by the [Green Bank Telescope](https://en.wikipedia.org/wiki/Green_Bank_Telescope) in West Virginia, run it through a few algorithms, and see if we can't turn up an alien or two!

Spoiler alert: If you do everything right you WILL find what appears to maybe possibly be an alien!

Second spoiler alert: It's not an alien. It's [Voyager 1!](https://en.wikipedia.org/wiki/Voyager_1) the farthest human-made object from Earth! Which is still awesome ;)

The process by which we find Voyager 1 will be nearly identical to the process you will use to search
for aliens in other data sets. So buckle up and listen close: It's time to look for ET.

**NOTE**: This tutorial assumes that you have already completed the [First Voyager Tutorial](https://github.com/UCBerkeleySETI/blimpy/blob/master/examples/voyager.ipynb).

Also, [click here](https://youtu.be/EFxUHoXW1cA) if you'd like to watch a poster tour about the summer research project that this tutorial is based on.

## Background

One of the largest challenges in SETI's search is that human-generated radio frequency interference (RFI) from cell phones, Wi-Fi, radar, etc, is much more abundant and powerful than potential alien-generated signals. Therefore two primary techniques are employed to quickly discriminate between RFI and potential alien sources. They're pretty simple and quite effective and understanding them is prerequisite for the rest of this tutorial. For a more thorough background discussion, [read through this tutorial](https://github.com/UCBerkeleySETI/breakthrough/tree/master/GBT).

### Technique 1: Pointing the telescope ON and OFF Target

   When a single dish radio telescope like Green Bank conducts an alien search, we program it to point directly at the target of interest (eg a star known to have an exoplanet in its "habitable zone") for 5 minutes, then point elsewhere for 5 minutes, then point back at the target for 5 minutes, then point some new place for 5 minutes, then back to the target for 5 minutes and finally 5 more minutes in a third new direction. If we call the observations pointing at the target "ON" observations and the observations pointing elsewhere "OFF" observations, the pattern looks like this:
   
   **1 "ON" --> 1 "OFF" --> 2 "ON" --> 2 "OFF" --> 3 "ON" --> 3 "OFF"**. In total, we do 3 five minute "ON" observations and 3 five-minute "OFF" observations, meaning the full search time for a particular target is half an hour!
    
   This is also referred to as an ABACAD pattern (for the alien-hunting songwriters amongst you, it could be fun to write a song about aliens with [the same form](https://www.omarimc.com/a-complete-guide-to-song-form-structure-examples-aaba-aaa-abab-abac/) as a SETI-search ;-)
    
   Conducting the search in this manner takes advantage of the fact that **most RFI should appear regardless of which direction the telescope is pointed in, while signals from space should appear only when the telescope is pointed directly at them**. Therefore, if we see a signal present in all three ON observations and absent in all three OFF observations we can be fairly confident that it's coming from space and not RFI!
    
### Technique 2: Nonzero Doppler Drift

   You may already be familiar with the concept of [Doppler Shift](https://en.wikipedia.org/wiki/Doppler_effect). But are you familiar with the concept of Doppler *Drift*? In short, Doppler Shift is a *constant* change in frequency due to a *constant* relative velocity between two objects, whereas Doppler Drift is a *changing* change in frequency due to a *changing* relative velocity between two objects. Since the Earth is rotating and orbiting (and space targets like exoplanets have their own changing speeds), things in outer space have a changing relative velocity to the Earth. Meanwhile, Earthbound objects have a constant velocity relative to Earth. Therefore, **most RFI does NOT have a Doppler Drift while outer space targets DO have Doppler Drift**.
   
We take advantage of this fact to get rid of more RFI by rejecting all signals that have zero Doppler Drift.

## Overview
    
The alien-search data analysis process can be broken down into five steps that look something like this:

> **1. telescope data** (in .h5 or filterbank format) --> **2. turboSETI** (outputs .dat) --> **3. find_event** (outputs Pandas and .csv) --> **4. plot_event_pipeline** (outputs corresponding time vs frequency graph with power indicated by color for each of the find_event hits you see in the Pandas dataframe) --> **5. plot_spectrum.py"** (outputs a power vs frequency graph)

Here's a quick explanation for each of these parts. The rest of this tutorial will go into more depth, but it's good to have an overview to start:

**1. telescope data**: The data that the telescope gathered should be stored somewhere in .h5 or filterbank format. For the purposes of this tutorial, I will assume we are using .h5 formatting but it shouldn't make a difference if you're using a filterbank file.

**2. turboSETI**: The main algorithm that processes the data collected from the telescopes in .h5 format and outputs
    .dat files. It often takes a long time to run (hours) on the multiple Gigabyte-sized .h5 files so you should connect to Berkeley's server if you are permitted using ssh. [Here's one](https://github.com/DominicL3/hey-aliens/blob/master/multihop-ssh.md) and [here's another](https://semaphoreci.com/community/tutorials/getting-started-with-ssh) useful resource for setting up ssh. Once logged in you'll use [tmux](https://github.com/tmux/tmux/wiki) or [screen](https://linuxize.com/post/how-to-use-linux-screen/) to allow turboSETI to continue running while your computer is disconnected from the Berkeley server. [Here](https://www.hamvocke.com/blog/a-quick-and-easy-guide-to-tmux/) is a helpful guide to using tmux. The most important section is on "session handling". The basic idea is: connect to Berkeley's server, activate tmux-->Run turboSETI-->detach from the session. You can then attach to the session again later to check if turboSETI is finished doing its thang.

**3. find_event.py**: The script that works in conjuction with **find_event_pipeline.py** to take in turboSETI's .dat files and outputs a Pandas dataframe that includes all events above a certain threshold AND a .csv file that you will manually input to plot_event_pipeline. When you think of find_event.py,      picture something like this (this is what a Pandas dataframe looks like): ![image.png](attachment:64dcf77d-a236-4e17-aacd-9e3cba76e611.png)
    
**4. plot_event_pipeline.py**: Do not confuse with **find_event_pipeline.py**!! This function takes in the output .csv from find_event.py and a .lst list of turboSETI's six .dat outputs (that you make--very easy) and gives you plots for each of the find_event.py hits that you see in the Pandas dataframe above! The plots are time vs frequency with power indicated by color. Importantly, as you can see below, there are SIX plots contained in one, corresponding to the six "ON/OFF" observations taken by the telescope. Each five minute (300 second) "ON" or "OFF" observation is separated by a horizontal black line. The uppermost five minute observation is the first "ON", followed underneath by the first "OFF", then the second "ON", etc. When you think of plot_event_pipeline.py, picture something like this: 

![image.png](attachment:b2642fbc-a2c3-40db-abb9-9b4e8c78e412.png)

**5. plot_spectrum.py**: Input some telescope data (.h5 file) and a frequency range and it outputs a power vs frequency graph. Note that the plot_spectrum graph is giving you the SAME information as one of the six 300-second plot_event graphs above (in between two horizontal black lines), but with the times "collapsed" (added together) so that the signal's power is represented by the height of the graph instead of by its brightness, and the time period is now the entire 300 second observation. When you think of plot_spectrum.py, picture something like this:

![image.png](attachment:db2ed43a-df73-45ca-97af-da59b831d43f.png)

## 0. Setup
We're going to start by setting up our environment in Jupyter Notebook by importing the necessary libraries and use %matplotlib inline" for proper formatting.


```python
%matplotlib inline
import pylab as plt
from blimpy import Waterfall
import turbo_seti.find_doppler.seti_event as turbo
import turbo_seti.find_event as find
```

You also need to install turboSETI and Blimpy. Please see [Shane Smith's tutorial](https://github.com/UCBerkeleySETI/turbo_seti/blob/master/tutorial/turboSETI_tutorial.ipynb) for directions.

## 1. Telescope Data

Next we need to get the Voyager 1 data collected by the Greenbank telescope on July 16th, 2020.

Download the data here (it's in .h5 format and each file is ~50 MB):

[First ON Observation](http://blpd14.ssl.berkeley.edu/voyager_2020/single_coarse_channel/single_coarse_guppi_59046_80036_DIAG_VOYAGER-1_0011.rawspec.0000.h5)

[First OFF Observation](http://blpd14.ssl.berkeley.edu/voyager_2020/single_coarse_channel/single_coarse_guppi_59046_80354_DIAG_VOYAGER-1_0012.rawspec.0000.h5)

[Second ON Observation](http://blpd14.ssl.berkeley.edu/voyager_2020/single_coarse_channel/single_coarse_guppi_59046_80672_DIAG_VOYAGER-1_0013.rawspec.0000.h5)

[Second OFF Observation](http://blpd14.ssl.berkeley.edu/voyager_2020/single_coarse_channel/single_coarse_guppi_59046_80989_DIAG_VOYAGER-1_0014.rawspec.0000.h5)

[Third ON Observation](http://blpd14.ssl.berkeley.edu/voyager_2020/single_coarse_channel/single_coarse_guppi_59046_81310_DIAG_VOYAGER-1_0015.rawspec.0000.h5)

[Third OFF Observation](http://blpd14.ssl.berkeley.edu/voyager_2020/single_coarse_channel/single_coarse_guppi_59046_81628_DIAG_VOYAGER-1_0016.rawspec.0000.h5)

## 2. turboSETI

To run turboSETI on the Voyager data we first need to create a list with the file names we downloaded. One way to do this is as follows:
1. Move the downloaded files to your current working directory in Jupyter Notebook (In my case, I opened Jupyter from my ~/Desktop directory and then stored the files in a folder on my desktop called "VoyagerData"). Make sure you keep the files in the right order.
2. Use the "glob" function to put them in .lst format. The glob function takes all files of a given format in your current working directory and puts them in a list, so make sure the Voyager files are the only files of this type in your current directory before using it.

You could also do this by hand, copying and pasting the file names into a .lst file, but who wants to pass up a chance to glob?!


```python
import glob

voyager_list = glob.glob('VoyagerData/*.h5') #This takes all .h5 files in my VoyagerData folder and puts them in a list

print(voyager_list)
```

    ['VoyagerData/single_coarse_guppi_59046_80036_DIAG_VOYAGER-1_0011.rawspec.0000.h5', 'VoyagerData/single_coarse_guppi_59046_80672_DIAG_VOYAGER-1_0013.rawspec.0000.h5', 'VoyagerData/single_coarse_guppi_59046_81628_DIAG_VOYAGER-1_0016.rawspec.0000.h5', 'VoyagerData/single_coarse_guppi_59046_81310_DIAG_VOYAGER-1_0015.rawspec.0000.h5', 'VoyagerData/single_coarse_guppi_59046_80989_DIAG_VOYAGER-1_0014.rawspec.0000.h5', 'VoyagerData/single_coarse_guppi_59046_80354_DIAG_VOYAGER-1_0012.rawspec.0000.h5']



```python
#This is a TEST CELL that will be DELETED

from blimpy import Waterfall
fb = Waterfall('VoyagerData/single_coarse_guppi_59046_80036_DIAG_VOYAGER-1_0011.rawspec.0000.h5')
fb.info()
data = fb.data
```

    
    --- File Info ---
    DIMENSION_LABELS : [b'time' b'feed_id' b'frequency']
            az_start :                              0.0
           data_type :                                1
                fch1 :                8421.38671875 MHz
                foff :      -2.7939677238464355e-06 MHz
          machine_id :                               20
               nbits :                               32
              nchans :                          1048576
                nifs :                                1
         source_name :                        VOYAGER-1
             src_dej :                     12:24:13.614
             src_raj :                     17:12:40.481
        telescope_id :                                6
               tsamp :               18.253611007999982
       tstart (ISOT) :          2020-07-16T22:13:56.000
        tstart (MJD) :                59046.92634259259
            za_start :                              0.0
    
    Num ints in file :                               16
          File shape :                 (16, 1, 1048576)
    --- Selection Info ---
    Data selection shape :                 (16, 1, 1048576)
    Minimum freq (MHz) :                8418.457034043968
    Maximum freq (MHz) :                    8421.38671875


Now that we have our files in a list we can run turboSETI on them with a or loop on them


```python
from turbo_seti.find_doppler.find_doppler import FindDoppler
FindDoppler?

for file in voyager_list:
    doppler = FindDoppler(file,
                      max_drift = 4,
                      snr = 10,       
                      out_dir = './' # This is where the turboSETI output files will be stored. "./" is the current directory
                     )
    doppler.search()
```


    [0;31mInit signature:[0m
    [0mFindDoppler[0m[0;34m([0m[0;34m[0m
    [0;34m[0m    [0mdatafile[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m    [0mmax_drift[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m    [0mmin_drift[0m[0;34m=[0m[0;36m0[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m    [0msnr[0m[0;34m=[0m[0;36m25.0[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m    [0mout_dir[0m[0;34m=[0m[0;34m'./'[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m    [0mcoarse_chans[0m[0;34m=[0m[0;32mNone[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m    [0mobs_info[0m[0;34m=[0m[0;32mNone[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m    [0mflagging[0m[0;34m=[0m[0;32mNone[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m    [0mn_coarse_chan[0m[0;34m=[0m[0;32mNone[0m[0;34m,[0m[0;34m[0m
    [0;34m[0m[0;34m)[0m[0;34m[0m[0;34m[0m[0m
    [0;31mInit docstring:[0m
    Initializes FindDoppler object
    
    Args:
        datafile (string):  Inputted filename (.h5 or .fil)
        max_drift (float):  Max drift rate in Hz/second
        min_drift (int):    Min drift rate in Hz/second
        snr (float):        Signal to Noise Ratio - A ratio bigger than 1 to 1 has more signal than  noise
        out_dir (string):   Directory where output files should be placed. By default this is the
                            current working directory.
        coarse_chans (list(int)):  the inputted comma separated list of coarse channels to analyze, if any.
        obs_info (dict):     Used to hold info found on file, including info about pulsars, RFI, and SEFD
        flagging (bool):     Flags the edges of the PFF for BL data (with 3Hz res per channel)
        n_coarse_chan (int): Number of coarse channels in file
    [0;31mFile:[0m           ~/miniconda3/lib/python3.7/site-packages/turbo_seti/find_doppler/find_doppler.py
    [0;31mType:[0m           type
    [0;31mSubclasses:[0m     




```python

```

## 3. find_event_pipeline



```python
#Using find_event_pipeline with filter threshold 3 to detect Voyager!
from find_event_pipeline import find_event_pipeline

find_event_pipeline('new_dat_files.lst',
                                        filter_threshold = 3,
                                        number_in_cadence = 6)
```

    
    ************   BEGINNING FIND_EVENT PIPELINE   **************
    
    Assuming the first observation is an ON
    There are 6 total files in the filelist new_dat_files.lst
    therefore, looking for events in 1 on-off set(s)
    with a minimum SNR of 10
    Present in all A sources with RFI rejection from the off-sources
    not including signals with zero drift
    saving the output files
    
    ***       DIAG       ***
    
    ------   o   -------
    Loading data...
    Loaded 1194 hits from /datax/scratch/elavie/turboSETI2/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_80036_DIAG_VOYAGER-1_0011.rawspec.0000.dat
    Loaded 1145 hits from /datax/scratch/elavie/turboSETI2/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_80354_DIAG_VOYAGER-1_0012.rawspec.0000.dat
    Loaded 1150 hits from /datax/scratch/elavie/turboSETI2/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_80672_DIAG_VOYAGER-1_0013.rawspec.0000.dat
    Loaded 1183 hits from /datax/scratch/elavie/turboSETI2/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_80989_DIAG_VOYAGER-1_0014.rawspec.0000.dat
    Loaded 1193 hits from /datax/scratch/elavie/turboSETI2/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_81310_DIAG_VOYAGER-1_0015.rawspec.0000.dat
    Loaded 1269 hits from /datax/scratch/elavie/turboSETI2/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_81628_DIAG_VOYAGER-1_0016.rawspec.0000.dat
    All data loaded!
    
    Finding events in this cadence...
    Found a total of 53 hits above the SNR cut in this cadence!
    Found a total of 31 hits in only the on observations in this cadence!
    Found a total of 2 events across this cadence!
    Search time: 0.29 sec
    ------   o   -------
    *** find_event_output_dataframe is complete ***
    find_event_pipeline: Saved CSV file to DIAG_VOYAGER-1_f3_snr10.csv





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TopHitNum</th>
      <th>DriftRate</th>
      <th>SNR</th>
      <th>Freq</th>
      <th>ChanIndx</th>
      <th>FreqStart</th>
      <th>FreqEnd</th>
      <th>CoarseChanNum</th>
      <th>FullNumHitsInRange</th>
      <th>FileID</th>
      <th>...</th>
      <th>MJD</th>
      <th>RA</th>
      <th>DEC</th>
      <th>DELTAT</th>
      <th>DELTAF</th>
      <th>Hit_ID</th>
      <th>status</th>
      <th>in_n_ons</th>
      <th>RFI_in_range</th>
      <th>delta_t</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>936</th>
      <td>937</td>
      <td>-0.363527</td>
      <td>22.329223</td>
      <td>8419.565390</td>
      <td>651879</td>
      <td>8419.567024</td>
      <td>8419.563761</td>
      <td>915</td>
      <td>36243</td>
      <td>spliced_blc00010203040506o7o0111213141516o7o02...</td>
      <td>...</td>
      <td>59046.926342592589</td>
      <td>17h12m40.481s</td>
      <td>12d24m13.614s</td>
      <td>18.253611</td>
      <td>-2.793968</td>
      <td>VOYAGER-1_936</td>
      <td>on_table_1</td>
      <td>2</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2129</th>
      <td>936</td>
      <td>-0.401793</td>
      <td>10.996980</td>
      <td>8419.565152</td>
      <td>651964</td>
      <td>8419.566787</td>
      <td>8419.563523</td>
      <td>915</td>
      <td>13855</td>
      <td>spliced_blc00010203040506o7o0111213141516o7o02...</td>
      <td>...</td>
      <td>59046.933703703704</td>
      <td>17h12m40.482s</td>
      <td>12d24m13.656s</td>
      <td>18.253611</td>
      <td>-2.793968</td>
      <td>VOYAGER-1_936</td>
      <td>on_table_2</td>
      <td></td>
      <td>0</td>
      <td>636.0</td>
    </tr>
    <tr>
      <th>3306</th>
      <td>963</td>
      <td>-0.411359</td>
      <td>18.530028</td>
      <td>8419.564890</td>
      <td>652058</td>
      <td>8419.566524</td>
      <td>8419.563261</td>
      <td>915</td>
      <td>17964</td>
      <td>spliced_blc00010203040506o7o0111213141516o7o02...</td>
      <td>...</td>
      <td>59046.941087962965</td>
      <td>17h12m40.477s</td>
      <td>12d24m13.608s</td>
      <td>18.253611</td>
      <td>-2.793968</td>
      <td>VOYAGER-1_936</td>
      <td>on_table_3</td>
      <td></td>
      <td>0</td>
      <td>1274.0</td>
    </tr>
    <tr>
      <th>937</th>
      <td>938</td>
      <td>-0.353960</td>
      <td>192.896198</td>
      <td>8419.542731</td>
      <td>659989</td>
      <td>8419.544365</td>
      <td>8419.541102</td>
      <td>915</td>
      <td>36243</td>
      <td>spliced_blc00010203040506o7o0111213141516o7o02...</td>
      <td>...</td>
      <td>59046.926342592589</td>
      <td>17h12m40.481s</td>
      <td>12d24m13.614s</td>
      <td>18.253611</td>
      <td>-2.793968</td>
      <td>VOYAGER-1_937</td>
      <td>on_table_1</td>
      <td>2</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2130</th>
      <td>937</td>
      <td>-0.382660</td>
      <td>82.805017</td>
      <td>8419.542493</td>
      <td>660074</td>
      <td>8419.544128</td>
      <td>8419.540864</td>
      <td>915</td>
      <td>13855</td>
      <td>spliced_blc00010203040506o7o0111213141516o7o02...</td>
      <td>...</td>
      <td>59046.933703703704</td>
      <td>17h12m40.482s</td>
      <td>12d24m13.656s</td>
      <td>18.253611</td>
      <td>-2.793968</td>
      <td>VOYAGER-1_937</td>
      <td>on_table_2</td>
      <td></td>
      <td>0</td>
      <td>636.0</td>
    </tr>
    <tr>
      <th>3307</th>
      <td>964</td>
      <td>-0.430492</td>
      <td>145.127964</td>
      <td>8419.542236</td>
      <td>660166</td>
      <td>8419.543871</td>
      <td>8419.540607</td>
      <td>915</td>
      <td>17964</td>
      <td>spliced_blc00010203040506o7o0111213141516o7o02...</td>
      <td>...</td>
      <td>59046.941087962965</td>
      <td>17h12m40.477s</td>
      <td>12d24m13.608s</td>
      <td>18.253611</td>
      <td>-2.793968</td>
      <td>VOYAGER-1_937</td>
      <td>on_table_3</td>
      <td></td>
      <td>0</td>
      <td>1274.0</td>
    </tr>
  </tbody>
</table>
<p>6 rows × 21 columns</p>
</div>



## 4. plot_event_pipeline



```python
import os
from sofias_code.plot_event_pipeline import plot_event_pipeline

# and finally we plot
plot_event_pipeline('/home/elavie/DIAG_VOYAGER-1_f3_snr10.csv',
                    '/home/elavie/Voyager2020.lst',
                    user_validation=True)

```

    Plotting some events for:  VOYAGER-1
    There are 6 total events in the csv file /home/elavie/DIAG_VOYAGER-1_f3_snr10.csv
    therefore, you are about to make 6 .png files.


    Do you wish to proceed with these settings? (y/n):  y


    
    *************************************************
    ***     The Parameters for This Plot Are:    ****
    Target =  VOYAGER-1
    Bandwidth =  0.00163  MHz
    Time Elapsed (inc. Slew) =  1866.0  s
    Middle Frequency =  8419.5654  MHz
    Expected Drift =  -0.3635  Hz/s
    *************************************************
    *************************************************
    
    
    *************************************************
    ***     The Parameters for This Plot Are:    ****
    Target =  VOYAGER-1
    Bandwidth =  0.0018  MHz
    Time Elapsed (inc. Slew) =  1866.0  s
    Middle Frequency =  8419.5652  MHz
    Expected Drift =  -0.4018  Hz/s
    *************************************************
    *************************************************
    
    
    *************************************************
    ***     The Parameters for This Plot Are:    ****
    Target =  VOYAGER-1
    Bandwidth =  0.00184  MHz
    Time Elapsed (inc. Slew) =  1866.0  s
    Middle Frequency =  8419.5649  MHz
    Expected Drift =  -0.4114  Hz/s
    *************************************************
    *************************************************
    
    
    *************************************************
    ***     The Parameters for This Plot Are:    ****
    Target =  VOYAGER-1
    Bandwidth =  0.00159  MHz
    Time Elapsed (inc. Slew) =  1866.0  s
    Middle Frequency =  8419.5427  MHz
    Expected Drift =  -0.354  Hz/s
    *************************************************
    *************************************************
    
    
    *************************************************
    ***     The Parameters for This Plot Are:    ****
    Target =  VOYAGER-1
    Bandwidth =  0.00171  MHz
    Time Elapsed (inc. Slew) =  1866.0  s
    Middle Frequency =  8419.5425  MHz
    Expected Drift =  -0.3827  Hz/s
    *************************************************
    *************************************************
    
    
    *************************************************
    ***     The Parameters for This Plot Are:    ****
    Target =  VOYAGER-1
    Bandwidth =  0.00193  MHz
    Time Elapsed (inc. Slew) =  1866.0  s
    Middle Frequency =  8419.5422  MHz
    Expected Drift =  -0.4305  Hz/s
    *************************************************
    *************************************************
    



![png](output_16_3.png)



![png](output_16_4.png)



![png](output_16_5.png)



![png](output_16_6.png)



![png](output_16_7.png)



![png](output_16_8.png)


## 5. plot_spectrum


```python
#Plotting spectrum for first OFF observation:

file_path = '/mnt_blpd14/datax2/voyager_2020/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_80354_DIAG_VOYAGER-1_0012.rawspec.0000.h5'
f_start = 8419.51
f_stop = 8419.58
obs = Waterfall(file_path, f_start, f_stop)

obs.plot_spectrum(f_start=f_start, f_stop=f_stop)
```

    extracting integration 0...



![png](output_18_1.png)



```python
#Plotting spectrum for second ON observation:

file_path = '/mnt_blpd14/datax2/voyager_2020/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_80672_DIAG_VOYAGER-1_0013.rawspec.0000.h5'
f_start = 8419.51
f_stop = 8419.58
obs = Waterfall(file_path, f_start, f_stop)

obs.plot_spectrum(f_start=f_start, f_stop=f_stop)
```

    extracting integration 0...



![png](output_19_1.png)



```python
#Plotting spectrum for second OFF observation:

file_path = '/mnt_blpd14/datax2/voyager_2020/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_80989_DIAG_VOYAGER-1_0014.rawspec.0000.h5'
f_start = 8419.51
f_stop = 8419.58
obs = Waterfall(file_path, f_start, f_stop)

obs.plot_spectrum(f_start=f_start, f_stop=f_stop)
```

    extracting integration 0...



![png](output_20_1.png)



```python
#Plotting spectrum for third ON observation:

file_path = '/mnt_blpd14/datax2/voyager_2020/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_81310_DIAG_VOYAGER-1_0015.rawspec.0000.h5'
f_start = 8419.51
f_stop = 8419.58
obs = Waterfall(file_path, f_start, f_stop)

obs.plot_spectrum(f_start=f_start, f_stop=f_stop)
```

    extracting integration 0...



![png](output_21_1.png)



```python
#Plotting spectrum for third OFF observation:

file_path = '/mnt_blpd14/datax2/voyager_2020/spliced_blc00010203040506o7o0111213141516o7o021222324252627_guppi_59046_81628_DIAG_VOYAGER-1_0016.rawspec.0000.h5'
f_start = 8419.51
f_stop = 8419.58
obs = Waterfall(file_path, f_start, f_stop)

obs.plot_spectrum(f_start=f_start, f_stop=f_stop)
```

    extracting integration 0...



![png](output_22_1.png)


## Conclusions

We found Voyager and *only* Voyager from over 7,000 RFI signals during the observation. Pretty impressive!

## Words of Gratitude

Steve Croft, Shane Smith



```python

```
